// ignore_for_file: prefer_const_constructors, curly_braces_in_flow_control_structures, must_be_immutable

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:persistent_bottom_nav_bar/persistent_bottom_nav_bar.dart';
import 'package:truck_market_place/service/controller/home_controller.dart';
import 'package:truck_market_place/views/favourites.dart';
import 'package:truck_market_place/views/home_screen.dart';
import 'package:truck_market_place/views/profile/profile.dart';
import 'package:truck_market_place/views/sell/basic_info.dart';
import 'package:truck_market_place/widget/colors.dart';

class BottomNav extends StatefulWidget {
  final int currentIndexx;
  int? tabIndex;

  BottomNav({super.key, required this.currentIndexx, this.tabIndex});

  @override
  State<BottomNav> createState() => _BottomNavState();
}

class _BottomNavState extends State<BottomNav> {
  int currentIndex = 0;
  late PersistentTabController _controller;

  @override
  void initState() {
    super.initState();
    currentIndex = widget.currentIndexx;
    _controller = PersistentTabController(initialIndex: currentIndex);
  }

  List<Widget> _buildScreens() {
    return [
      HomeScreen(),
      Favourites(),
      BasicInfo(),
      // Container(color: AppColors.appBar),
      ProfileScreen(),
    ];
  }

  final HomeController _homeController = Get.put(HomeController());

  List<PersistentBottomNavBarItem> _navBarsItems() {
    return [
      PersistentBottomNavBarItem(
        icon: Icon(Icons.home),
        title: "Home",
        activeColorPrimary: AppColors.primaryColor,
        inactiveColorPrimary: AppColors.dotColor,
      ),
      PersistentBottomNavBarItem(
        icon: Icon(Icons.favorite),
        title: "Favourite",
        activeColorPrimary: AppColors.primaryColor,
        inactiveColorPrimary: AppColors.dotColor,
      ),
      PersistentBottomNavBarItem(
        icon: Icon(Icons.currency_exchange_rounded),
        title: "Sell",
        activeColorPrimary: AppColors.primaryColor,
        inactiveColorPrimary: AppColors.dotColor,
      ),
      PersistentBottomNavBarItem(
        icon: Icon(Icons.person),
        title: "Profile",
        activeColorPrimary: AppColors.primaryColor,
        inactiveColorPrimary: AppColors.dotColor,
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: PersistentTabView(
        context,
        controller: _controller,
        screens: _buildScreens(),
        items: _navBarsItems(),
        onItemSelected: (index) async {
          if (index == 2) {
            await showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
              ),
              builder: (context) => _buildSellSheet(),
            );
            _controller.index = currentIndex;
          } else {
            setState(() {
              currentIndex = index;
              _controller.index = index;
            });
          }
        },
        backgroundColor: AppColors.white,
        handleAndroidBackButtonPress: false,
        resizeToAvoidBottomInset: true,
        stateManagement: false,
        navBarHeight: MediaQuery.of(context).viewInsets.bottom > 0
            ? 0.0
            : kBottomNavigationBarHeight,
        hideNavigationBarWhenKeyboardAppears: true,
        animationSettings: const NavBarAnimationSettings(
          navBarItemAnimation: ItemAnimationSettings(
            duration: Duration(milliseconds: 400),
            curve: Curves.ease,
          ),
          screenTransitionAnimation: ScreenTransitionAnimationSettings(
            animateTabTransition: true,
            duration: Duration(milliseconds: 200),
            screenTransitionAnimationType: ScreenTransitionAnimationType.fadeIn,
          ),
        ),
        popBehaviorOnSelectedNavBarItemPress: PopBehavior.all,
        padding: EdgeInsets.only(top: 4, bottom: 8),
        decoration: NavBarDecoration(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(25.0),
            topRight: Radius.circular(25.0),
          ),
          colorBehindNavBar: Colors.white,
        ),
        navBarStyle: NavBarStyle.style6,
      ),
    );
  }

  Widget _buildSellSheet() {
    return Container(
      padding: EdgeInsets.all(16),
      height: 550.h,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),

          Center(
            child: Image.asset('assets/images/app_logo.png', height: 100.h),
          ),

          _optionCard(
            icon: Icons.local_shipping,
            iconColor: AppColors.primaryColor,
            title: "Equipment Information",
            subtitle: "Fill in the specification for your truck or trailer.",
          ),
          SizedBox(height: 12.h),
          _optionCard(
            icon: Icons.request_quote,
            iconColor: Colors.orange,
            title: "Order on inspection",
            subtitle:
                "Once we have information about your truck or trailer, we will contact you regarding an inspection appointment.",
          ),
          SizedBox(height: 12.h),
          _optionCard(
            icon: Icons.lightbulb,
            iconColor: AppColors.splash1,
            title: "List your vechicle",
            subtitle:
                "Once an inspection report is recieved your equipment will be listed for sell",
          ),

          Spacer(),

          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop(); // close sheet
                setState(() {
                  currentIndex = 2;
                  _controller.index = 2;
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.r),
                ),
                padding: EdgeInsets.symmetric(vertical: 14.h),
              ),
              child: Text(
                "Continue",
                style: GoogleFonts.inter(
                  fontSize: 16.sp,
                  color: AppColors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          SizedBox(height: 30.h),
        ],
      ),
    );
  }

  Widget _optionCard({
    required IconData icon,
    required String title,
    required String subtitle,

    required Color iconColor,
  }) {
    return Container(
      padding: EdgeInsets.all(12.w),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12.r),
        color: Colors.grey.shade100,
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: iconColor.withOpacity(0.1),
            radius: 24.r,
            child: Icon(icon, color: iconColor, size: 24.sp),
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.inter(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 4.h),
                Text(
                  subtitle,
                  style: GoogleFonts.inter(
                    fontSize: 12.sp,
                    color: AppColors.hintTxtColor,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
