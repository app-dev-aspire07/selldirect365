import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shimmer/shimmer.dart';
import 'package:truck_market_place/service/api_url.dart';
import 'package:truck_market_place/service/controller/home_controller.dart';
import 'package:truck_market_place/views/detailed_screens/truck_by_cat.dart';
import 'package:truck_market_place/views/detailed_screens/truck_details.dart';
import 'package:truck_market_place/views/detailed_screens/truck_list.dart';
import 'package:truck_market_place/widget/app_bar.dart';
import 'package:truck_market_place/widget/colors.dart';
import 'package:truck_market_place/widget/common_list_model.dart';
import 'package:truck_market_place/widget/common_text.dart';
import 'package:truck_market_place/widget/dimensions.dart';
import 'package:truck_market_place/widget/route.dart';

class HomeScreen extends StatelessWidget {
  HomeScreen({super.key});

  final TextEditingController _controller = TextEditingController();

  final HomeController _homeController = Get.find();

  // loadData() async{
  //   var repo = await ApiRepository.demoUser();
  //   if (repo.name != null || repo.name!.isNotEmpty) {
  //     print("success");
  //   }else{
  //     print("Failed");
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: withoutBackAppBar(
        context,
        title: "Home",
        actions: [
          IconButton(
            icon: Icon(Icons.notifications, color: AppColors.white),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: SizedBox(
                  height: 40.h,
                  child: _textFormField(_controller),
                ),
              ),
              SizedBox(height: AppDimentions.pxh_10),
              CommonText(
                text: " Shop By Category",
                color: AppColors.black,
                fontWeight: FontWeight.bold,
                fontSize: AppDimentions.sp16,
              ),
              SizedBox(height: AppDimentions.pxh_6),
              SizedBox(
                height: AppDimentions.pxh100,
                child: Obx(() {
                  final isLoading = _homeController.isLoading.value;
                  final hasData = _homeController.categoriesList.isNotEmpty;
                  if (isLoading) {
                    return Shimmer.fromColors(
                      baseColor: Colors.grey.shade300,
                      highlightColor: Colors.transparent,
                      child: GridView.builder(
                        padding: EdgeInsets.zero,
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          childAspectRatio: 3 / 2.7,
                          crossAxisSpacing: 10,
                          mainAxisSpacing: 10,
                        ),
                        itemCount: 3,
                        itemBuilder: (context, index) {
                          return Card(
                            elevation: 4,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                          );
                        },
                      ),
                    );
                  }

                  if (!isLoading && !hasData) {
                    return Center(child: Text("No categories found"));
                  }

                  return GridView.builder(
                    padding: EdgeInsets.zero,
                    physics: NeverScrollableScrollPhysics(),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      childAspectRatio: 3 / 2.75,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                    ),
                    itemCount: _homeController.categoriesList.length,
                    itemBuilder: (context, index) {
                      final item = _homeController.categoriesList[index];
                      return InkWell(
                        onTap: () async{
                          Navigator.of(context).push(
                            createRoute(
                              TruckByCategories(
                                name: item.name ?? "",
                                catId: item.id,
                              ),
                            ),
                          );
                        },
                        child: Card(
                          elevation: 4,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                            side: BorderSide(
                              color: AppColors.hintTxtColor,
                              width: 0.4,
                            ),
                          ),
                          child: Container(
                            decoration: BoxDecoration(
                              color: AppColors.white,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  item.icon!.contains(".svg")
                                      ? SvgPicture.network(
                                          ApiEndPoints.imgBaseUrl + item.icon!,
                                          width: AppDimentions.pxw40,
                                          height: AppDimentions.pxh_40,
                                        )
                                      : CachedNetworkImage(
                                          imageUrl:
                                              ApiEndPoints.imgBaseUrl +
                                              item.icon!,
                                          width: AppDimentions.pxw40,
                                          height: AppDimentions.pxh_40,
                                        ),
                                  const SizedBox(height: 8),
                                  Text(
                                    item.name ?? "",
                                    style: GoogleFonts.poppins(
                                      fontSize: AppDimentions.sp11,
                                      fontWeight: FontWeight.w600,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  );
                }),
              ),
              SizedBox(height: AppDimentions.pxh_12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CommonText(
                    text: " Newly Added",
                    color: AppColors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: AppDimentions.sp16,
                  ),
                  InkWell(
                    onTap: () {
                      // Navigator.of(
                      //   context,
                      // ).push(createRoute(TruckList(name: "Newly Added"),  ));
                    },
                    child: CommonText(
                      text: "view all",
                      color: AppColors.primaryColor,
                      fontWeight: FontWeight.w400,
                      fontSize: AppDimentions.sp14,
                    ),
                  ),
                ],
              ),
              SizedBox(height: AppDimentions.pxh_6),
              Obx(() {
                final trucks = _homeController.getTruckList;

                if (_homeController.isLoading.value) {
                  // ✅ Shimmer Loading
                  return SizedBox(
                    height: 150.h,
                    child: ListView.separated(
                      padding: EdgeInsets.zero,
                      scrollDirection: Axis.horizontal,
                      itemCount: 4, // jitne shimmer dikhane ho
                      separatorBuilder: (_, __) => const SizedBox(width: 12),
                      itemBuilder: (context, index) {
                        return Shimmer.fromColors(
                          baseColor: Colors.grey.shade300,
                          highlightColor: Colors.grey.shade100,
                          child: Container(
                            width: 220.w,
                            decoration: BoxDecoration(
                              color: Colors.grey[300],
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Image placeholder
                                Container(
                                  height: 100.h,
                                  width: 220.w,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                                SizedBox(height: 8.h),
                                // Title + Price row
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 6,
                                  ),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Container(
                                        height: 12.h,
                                        width: 100.w,
                                        color: Colors.white,
                                      ),
                                      Container(
                                        height: 12.h,
                                        width: 40.w,
                                        color: Colors.white,
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 6.h),
                                // Location placeholder
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 6,
                                  ),
                                  child: Row(
                                    children: [
                                      Container(
                                        height: 12.h,
                                        width: 12.h,
                                        decoration: const BoxDecoration(
                                          color: Colors.white,
                                          shape: BoxShape.circle,
                                        ),
                                      ),
                                      SizedBox(width: 5.w),
                                      Container(
                                        height: 12.h,
                                        width: 120.w,
                                        color: Colors.white,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  );
                }

                if (trucks.isEmpty) {
                  return SizedBox(
                    height: 150.h,
                    child: const Center(child: Text("No trucks found")),
                  );
                }

                // ✅ Actual data list
                return SizedBox(
                  height: 150.h,
                  child: ListView.separated(
                    padding: EdgeInsets.zero,
                    shrinkWrap: true,
                    scrollDirection: Axis.horizontal,
                    itemCount: trucks.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (context, index) {
                      final truck = trucks[index];
                      return InkWell(
                        onTap: () {
                          Navigator.of(context).push(
                            createRoute(
                              TruckDetails(
                                name:
                                    "${truck.color} ${truck.brand} ${truck.model}",
                                    id: truck.id,

                              ),
                            ),
                          );
                        },
                        child: Container(
                          width: 220.w,
                          decoration: BoxDecoration(
                            color: AppColors.indicatorColor,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Stack(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: CachedNetworkImage(
                                      imageUrl:
                                          ApiEndPoints.imgUrl +
                                          truck.images![0],
                                      height: 100.h,
                                      width: 220.w,
                                      fit: BoxFit.cover,
                                      placeholder: (context, url) =>
                                          Shimmer.fromColors(
                                            baseColor: Colors.grey.shade300,
                                            highlightColor:
                                                Colors.grey.shade100,
                                            child: Container(
                                              height: 100.h,
                                              width: 220.w,
                                              color: Colors.white,
                                            ),
                                          ),
                                      errorWidget: (context, url, error) =>
                                          const Icon(Icons.error),
                                    ),
                                  ),
                                  Positioned(
                                    top: 4,
                                    right: 8,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Colors.transparent.withOpacity(
                                          0.1,
                                        ),
                                      ),
                                      child: const Padding(
                                        padding: EdgeInsets.all(2.0),
                                        child: Icon(
                                          Icons.favorite_border,
                                          size: 20,
                                          color: AppColors.black,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 4,
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          "${truck.color} ${truck.brand} ${truck.model}",
                                          style: GoogleFonts.inter(
                                            fontSize: 12.sp,
                                            color: AppColors.white,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                        Text(
                                          "\$${truck.price}",
                                          style: GoogleFonts.inter(
                                            fontSize: 12.sp,
                                            color: Colors.white,
                                            height: 0.9,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 4.h),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.location_on_outlined,
                                          size: 14.sp,
                                          color: Colors.white,
                                        ),
                                        SizedBox(width: 5.w),
                                        SizedBox(
                                          width: Get.width * 0.5,
                                          child: Text(
                                            truck.address ?? "",
                                            style: GoogleFonts.inter(
                                              fontSize: 9.sp,
                                              color: Colors.white,
                                              fontWeight: FontWeight.w600,
                                              height: 1,
                                            ),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                );
              }),
              SizedBox(height: AppDimentions.pxh_10),
              CommonText(
                text: " Manufacturers",
                color: AppColors.black,
                fontWeight: FontWeight.bold,
                fontSize: AppDimentions.sp16,
              ),
              SizedBox(height: AppDimentions.pxh_6),

              Obx(() {
                final isLoading = _homeController.isBrands.value;
                final hasData = _homeController.branList.isNotEmpty;

                if (isLoading) {
                  // Shimmer Loader
                  return Shimmer.fromColors(
                    baseColor: Colors.grey.shade300,
                    highlightColor: Colors.transparent,
                    child: GridView.builder(
                      padding: EdgeInsets.zero,
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: 6,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        childAspectRatio: 3 / 2.5,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                      ),
                      itemBuilder: (context, index) {
                        return Card(
                          elevation: 4,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        );
                      },
                    ),
                  );
                }

                if (!isLoading && !hasData) {
                  return Center(child: Text("No Brands Found"));
                }

                // Actual Data
                return GridView.builder(
                  padding: EdgeInsets.zero,
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: _homeController.branList.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    childAspectRatio: 3 / 2.7,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemBuilder: (context, index) {
                    return InkWell(
                      onTap: () {
                        Navigator.of(context).push(
                          createRoute(
                            TruckList(
                              name: _homeController.branList[index].optionValue,
                              id: _homeController.branList[index].id,
                            ),
                          ),
                        );
                      },
                      child: Card(
                        elevation: 4,
                        shape: RoundedRectangleBorder(
                          side: BorderSide(
                            color: AppColors.hintTxtColor,
                            width: 0.4,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            color: AppColors.white,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                _homeController.branList[index].icon!.contains(
                                      ".svg",
                                    )
                                    ? SvgPicture.network(
                                        "${ApiEndPoints.imgBaseUrl}icons/${_homeController.branList[index].icon!}",
                                      )
                                    : CachedNetworkImage(
                                        imageUrl:
                                            "${ApiEndPoints.imgBaseUrl}icons/${_homeController.branList[index].icon!}",
                                        width: AppDimentions.pxw40,
                                      ),
                                SizedBox(height: 2.h),
                                Text(
                                  _homeController.branList[index].optionValue
                                      .toString(),
                                  style: GoogleFonts.poppins(
                                    color: AppColors.black,
                                    fontWeight: FontWeight.w600,
                                    fontSize: AppDimentions.sp12,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                );
              }),
            ],
          ),
        ),
      ),
    );
  }

  TextFormField _textFormField(TextEditingController? controller) =>
      TextFormField(
        controller: controller,
        cursorColor: AppColors.hintTxtColor,

        style: GoogleFonts.inter(
          color: AppColors.black,
          fontWeight: FontWeight.w600,
        ),
        decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
            borderSide: BorderSide(color: AppColors.hintTxtColor),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
            borderSide: BorderSide(color: AppColors.hintTxtColor),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
            borderSide: BorderSide(color: AppColors.indicatorColor, width: 1.0),
          ),
          hint: Text("Search any keyword"),
          hintStyle: GoogleFonts.poppins(
            color: AppColors.hintTxtColor,
            fontWeight: FontWeight.w600,
          ),
          prefixIcon: Icon(Icons.search, color: AppColors.indicatorColor),
        ),
      );

  final List<CommonListItemModel> truckList = [
    CommonListItemModel(
      imageUrl: 'assets/statics/kenworth.png',
      title: 'Kenworth',
      subtitle: '',
    ),
    CommonListItemModel(
      imageUrl: 'assets/statics/freightliner.jpeg',
      title: 'Freightliner',
      subtitle: '',
    ),
    CommonListItemModel(
      imageUrl: 'assets/statics/peterbilt.jpeg',
      title: 'Peterbilt',
      subtitle: '',
    ),
    CommonListItemModel(
      imageUrl: 'assets/statics/volvo.png',
      title: 'Volvo',
      subtitle: '',
    ),
    CommonListItemModel(
      imageUrl: 'assets/statics/international.jpeg',
      title: 'International',
      subtitle: '',
    ),
    CommonListItemModel(
      imageUrl: 'assets/statics/westernstar.png',
      title: 'Western Star',
      subtitle: '',
    ),
    CommonListItemModel(
      imageUrl: 'assets/statics/wabash.png',
      title: 'Wabash',
      subtitle: '',
    ),
    CommonListItemModel(
      imageUrl: 'assets/statics/greatdane.png',
      title: 'Great Dane',
      subtitle: '',
    ),
    CommonListItemModel(
      imageUrl: 'assets/statics/utility.png',
      title: 'Utility',
      subtitle: '',
    ),
    CommonListItemModel(
      imageUrl: 'assets/statics/hyundai.png',
      title: 'Hyundai',
      subtitle: '',
    ),
    CommonListItemModel(
      imageUrl: 'assets/statics/stoughton.png',
      title: 'Stoughton',
      subtitle: '',
    ),
    CommonListItemModel(
      imageUrl: 'assets/statics/vanguard.png',
      title: 'Vanguard',
      subtitle: '',
    ),
  ];

  final List<CommonTruckListItemModel> newlyAdded = [
    CommonTruckListItemModel(
      imageUrl: 'assets/trucks/truck1.jpeg',
      title: '2023 Kenworth T680',
      subtitle: '',
      distance: "125369",
      price: "25000",
    ),
    CommonTruckListItemModel(
      imageUrl: 'assets/trucks/truck2.jpg',
      title: '2020 Peterbilt Model 389',
      subtitle: '',
      distance: "8757654",
      price: "37065",
    ),
    CommonTruckListItemModel(
      imageUrl: 'assets/trucks/truck3.jpg',
      title: '2013 Frieghtliner Cascadia 125',
      subtitle: '',
      distance: "55469",
      price: "12000",
    ),
    CommonTruckListItemModel(
      imageUrl: 'assets/trucks/truck4.jpg',
      title: '2015 Western Star 4700 SF',
      subtitle: '',
      distance: "166000",
      price: "94000",
    ),
    CommonTruckListItemModel(
      imageUrl: 'assets/trucks/truck5.jpg',
      title: '2019 International IT',
      subtitle: '',
      distance: "613847",
      price: "85700",
    ),
    CommonTruckListItemModel(
      imageUrl: 'assets/trucks/truck7.jpg',
      title: '2022 Volvo VNL 860',
      subtitle: '',
      distance: "767662",
      price: "45500",
    ),
  ];
}
