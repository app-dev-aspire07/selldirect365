import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:truck_market_place/views/profile/my_equipment.dart';
import 'package:truck_market_place/views/profile/sent_quote.dart';
import 'package:truck_market_place/widget/colors.dart';
import 'package:truck_market_place/widget/dimensions.dart';

class EquipmentInfo extends StatelessWidget {
  const EquipmentInfo({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2, // Two tabs
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: Hero(
            tag: "Equipment Info",
            child: Material(
              color: Colors.transparent,
              child: Text(
                "Equipment Info".toUpperCase(),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.poppins(
                  color: AppColors.white,
                  fontSize: AppDimentions.sp16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
          leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(Icons.arrow_back_ios, color: AppColors.white),
          ),
          backgroundColor: AppColors.appBar, // App bar dark color
          elevation: 0.0,
          toolbarHeight: 40.h,
          bottom: PreferredSize(
            preferredSize: Size.fromHeight(50.h),
            child: Container(
              color: Colors.white, // Tab bar white background
              child: TabBar(
                labelColor: AppColors.primaryColor,
                unselectedLabelColor: Colors.grey,
                indicatorColor: AppColors.primaryColor,
                labelStyle: GoogleFonts.poppins(
                  fontSize: AppDimentions.sp14,
                  fontWeight: FontWeight.w600,
                ),
                unselectedLabelStyle: GoogleFonts.poppins(
                  fontSize: AppDimentions.sp14,
                  fontWeight: FontWeight.w600,
                ),
                tabs: const [
                  Tab(text: 'Sent Quote'),
                  Tab(text: 'My Equipment'),
                ],
              ),
            ),
          ),
        ),
        body:  TabBarView(
          children: [
            SentQuote(),
            MyEquipments(),
          ],
        ),
      ),
    );
  }
}
