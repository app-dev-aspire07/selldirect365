import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:truck_market_place/views/profile/edit_profile.dart';
import 'package:truck_market_place/views/profile/equipment_info.dart';
import 'package:truck_market_place/views/profile/help_center.dart';
import 'package:truck_market_place/views/profile/setting.dart';
import 'package:truck_market_place/widget/app_bar.dart';
import 'package:truck_market_place/widget/colors.dart';
import 'package:truck_market_place/widget/show_popUp.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Navigator(
      key: GlobalKey<NavigatorState>(),
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case "/equipmentInfo":
            return MaterialPageRoute(builder: (_) => EquipmentInfo());
          case "/editProfile":
            return MaterialPageRoute(builder: (_) => EditProfile());
          case "/helpCenter":
            return MaterialPageRoute(builder: (_) => HelpCenter());
          case "/settings":
            return MaterialPageRoute(builder: (_) => SettingsScreen());
          default:
            return MaterialPageRoute(builder: (_) => const _ProfileHome());
        }
      },
    );
  }
}

/// 🔹 Ye tumhara actual profile UI hai jo Navigator ke andar home page ban gaya
class _ProfileHome extends StatelessWidget {
  const _ProfileHome();

  final String firstName = 'John';
  final String lastName = 'Doe';
  final String email = 'johndoe@gmail.com';
  final String? profileImageUrl = '';

  @override
  Widget build(BuildContext context) {
    final Color randomColor =
        Colors.primaries[Random().nextInt(Colors.primaries.length)];

    String initials =
        "${firstName.isNotEmpty ? firstName[0] : ''}${lastName.isNotEmpty ? lastName[0] : ''}"
            .toUpperCase();

    return Scaffold(
      appBar: withoutBackAppBar(context, title: "Account"),
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 20.h),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 30.r,
                    backgroundColor:
                        (profileImageUrl == null || profileImageUrl!.isEmpty)
                            ? randomColor
                            : Colors.transparent,
                    backgroundImage: profileImageUrl != null &&
                            profileImageUrl!.isNotEmpty
                        ? NetworkImage(profileImageUrl!)
                        : null,
                    child: (profileImageUrl == null ||
                            profileImageUrl!.isEmpty)
                        ? Text(
                            initials,
                            style: GoogleFonts.inter(
                              color: Colors.white,
                              fontSize: 20.sp,
                              fontWeight: FontWeight.bold,
                            ),
                          )
                        : null,
                  ),
                  SizedBox(width: 16.w),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "$firstName $lastName",
                        style: GoogleFonts.inter(
                          fontSize: 18.sp,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                        ),
                      ),
                      SizedBox(height: 4.h),
                      InkWell(
                        onTap: () =>
                            Navigator.of(context).pushNamed("/editProfile"),
                        child: Text(
                          "Edit Account",
                          style: GoogleFonts.inter(
                            fontSize: 13.sp,
                            color: Colors.grey,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 20.h),

            _profileTile(
              icon: Icons.description_outlined,
              title: "Equipment Info",
              subtitle: "Sent quote, My equipment",
              onTap: () => Navigator.of(context).pushNamed("/equipmentInfo"),
            ),
            _profileTile(
              icon: Icons.help_outline,
              title: "Help Center",
              subtitle: "FAQ’s, Contact support",
              onTap: () => Navigator.of(context).pushNamed("/helpCenter"),
            ),
            _profileTile(
              icon: Icons.phone,
              title: "Contact Us",
              subtitle: "Contact via call, email",
            ),
            _profileTile(
              icon: Icons.settings,
              title: "Settings",
              subtitle: "Change password, Deactivate account",
              onTap: () => Navigator.of(context).pushNamed("/settings"),
            ),

            SizedBox(height: 30.h),
            InkWell(
              onTap: () => ShowDialog.showLogOut(context),
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: AppColors.indicatorColor,
                  borderRadius: BorderRadius.circular(20.r),
                ),
                padding: EdgeInsets.symmetric(vertical: 14.h),
                child: Center(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.logout, color: Colors.white, size: 18.sp),
                      SizedBox(width: 8.w),
                      Text(
                        "Log Out",
                        style: GoogleFonts.inter(
                          color: Colors.white,
                          fontSize: 15.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(height: 20.h),
          ],
        ),
      ),
    );
  }

  Widget _profileTile({
    required IconData icon,
    required String title,
    String? subtitle,
    Function? onTap,
  }) {
    return Column(
      children: [
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: Icon(icon, color: Colors.grey.shade700),
          title: Text(
            title,
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.w600,
              fontSize: 14.sp,
              color: Colors.black,
            ),
          ),
          subtitle: subtitle != null
              ? Text(
                  subtitle,
                  style: GoogleFonts.inter(
                    fontSize: 12.sp,
                    color: Colors.grey,
                  ),
                )
              : null,
          onTap: onTap != null ? () => onTap() : null,
        ),
        Divider(height: 1.h, thickness: 0.6, color: Colors.grey.shade300),
      ],
    );
  }
}
