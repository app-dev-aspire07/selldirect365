import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:truck_market_place/views/detailed_screens/truck_details.dart';
import 'package:truck_market_place/widget/colors.dart';
import 'package:truck_market_place/widget/common_list_model.dart';
import 'package:truck_market_place/widget/route.dart';

class MyEquipments extends StatelessWidget {
   MyEquipments({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body:  Column(
        children: [
          SizedBox(height: 10.h,),
          Expanded(
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: _truckList.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: InkWell(
                    onTap: (){
                      Navigator.of(context).push(createRoute(TruckDetails(name: _truckList[index].title,)));
                    },
                    child: Card(
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width: 130.w,
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(10),
                                      bottomLeft: Radius.circular(10),
                                    ),
                                    child: Image.asset(
                                      _truckList[index].imageUrl,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                                SizedBox(width: 5.w),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      _truckList[index].title,
                                      style: GoogleFonts.inter(
                                        fontSize: 13.sp,
                                        color: AppColors.indicatorColor,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    SizedBox(height: 4.h),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.location_on_outlined,
                                          color: AppColors.primaryColor,
                                          size: 13.sp,
                                        ),
                                        Text(
                                          " French Camp, CA, US",
                                          style: GoogleFonts.inter(
                                            fontSize: 11.sp,
                                            color: AppColors.black,
                                            fontWeight: FontWeight.normal,
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 2.h),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                                            Icon(
                                              Icons.attach_money_outlined,
                                              color: AppColors.primaryColor,
                                              size: 13.sp,
                                            ),
                                            Text(
                                              "35000",
                                              style: GoogleFonts.inter(
                                                fontSize: 11.sp,
                                                color: AppColors.black,
                                                fontWeight: FontWeight.normal,
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(width: 20.w),
                                        Row(
                                          children: [
                                            Icon(
                                              Icons.speed_outlined,
                                              color: AppColors.primaryColor,
                                              size: 13.sp,
                                            ),
                                            Text(
                                              "164760",
                                              style: GoogleFonts.inter(
                                                fontSize: 11.sp,
                                                color: AppColors.black,
                                                fontWeight: FontWeight.normal,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 4.h),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          width: 120,
                                        ),
                                        Align(
                                          alignment: Alignment.centerRight,
                                          child: Text(
                                            "Request Pending",
                                            style: GoogleFonts.inter(
                                              fontSize: 12.sp,
                                              color: AppColors.indicatorColor,
                                              fontWeight: FontWeight.w700,

                                            ),
                                            textAlign: TextAlign.right,

                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 2.h),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          // SizedBox(height: 40.h,),
        ],
      ),
   
    );
  }
   final List<CommonTruckListItemModel> _truckList = [
    CommonTruckListItemModel(
      imageUrl: 'assets/trucks/truck1.jpeg',
      title: '2023 Kenworth T680',
      subtitle: '',
      distance: "125369",
      price: "25000",
    ),
    CommonTruckListItemModel(
      imageUrl: 'assets/trucks/truck2.jpg',
      title: '2020 Peterbilt Model 389',
      subtitle: '',
      distance: "8757654",
      price: "37065",
    ),
    CommonTruckListItemModel(
      imageUrl: 'assets/trucks/truck3.jpg',
      title: '2013 Frieghtliner Cascadia 125',
      subtitle: '',
      distance: "55469",
      price: "12000",
    ),
    CommonTruckListItemModel(
      imageUrl: 'assets/trucks/truck4.jpg',
      title: '2015 Western Star 4700 SF',
      subtitle: '',
      distance: "166000",
      price: "94000",
    ),
    CommonTruckListItemModel(
      imageUrl: 'assets/trucks/truck5.jpg',
      title: '2019 International IT',
      subtitle: '',
      distance: "613847",
      price: "85700",
    ),
    CommonTruckListItemModel(
      imageUrl: 'assets/trucks/truck7.jpg',
      title: '2022 Volvo VNL 860',
      subtitle: '',
      distance: "767662",
      price: "45500",
    ),
    
  ];
}