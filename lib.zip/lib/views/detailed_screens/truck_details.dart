import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:truck_market_place/model/Truck_Model/get_truck_id_model.dart';
import 'package:truck_market_place/service/api_url.dart';
import 'package:truck_market_place/service/controller/home_controller.dart';
import 'package:truck_market_place/widget/app_bar.dart';
import 'package:truck_market_place/widget/colors.dart';
import 'package:truck_market_place/widget/dimensions.dart';
import 'package:truck_market_place/widget/image_view.dart';
import 'package:truck_market_place/widget/route.dart';

class TruckDetails extends StatefulWidget {
  final String? name;
  final int? id;
  const TruckDetails({super.key, this.name, this.id});

  @override
  State<TruckDetails> createState() => _TruckDetailsState();
}

class _TruckDetailsState extends State<TruckDetails>
    with TickerProviderStateMixin {
  final PageController _pageController = PageController();
  bool _showMore = false;
  int currentPage = 0;
  final HomeController _homeController = Get.find();

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      loadData();
    });
  }

  loadData() async {
    await _homeController.fetchTruckById(widget.id!);
  }

  int _initialVisible = 3; // starting me 3 fields dikhenge

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: mainAppBar(context, title: widget.name),
      body: Obx(() {
        final truck = _homeController.truckDetail.value;

        if (truck == null) {
          return const Center(child: CircularProgressIndicator());
        }

        final images = truck.images ?? [];
        final address = truck.address ?? "N/A";
        final fields = truck.fields ?? [];

        // ✅ Helper to get field value by name
        String getField(String fieldName) {
          if (fields.isEmpty) return "N/A";
          try {
            final field = fields.firstWhere(
              (f) => f.fieldName?.toLowerCase() == fieldName.toLowerCase(),
              orElse: () => Field(optionValue: "N/A"),
            );
            return field.optionValue ?? "N/A";
          } catch (e) {
            return "N/A";
          }
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /// Top Image Slider
            SizedBox(
              height: 220.h,
              child: Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  PageView.builder(
                    controller: _pageController,
                    itemCount: images.length,
                    onPageChanged: (index) {
                      setState(() {
                        currentPage = index;
                      });
                    },
                    itemBuilder: (context, index) {
                      return InkWell(
                        onTap: () {
                          Navigator.of(context).push(
                            createRoute(
                              FullScreenImageViewer(
                                imagePaths:  images,
                                initialIndex: index,
                              ),
                            ),
                          );
                        },
                        child: ClipRRect(
                          child: CachedNetworkImage(
                            imageUrl: ApiEndPoints.imgUrl + images[index],
                            fit: BoxFit.cover,
                            width: double.infinity,
                          ),
                        ),
                      );
                    },
                  ),
                  Positioned(
                    bottom: 10.h,
                    child: SmoothPageIndicator(
                      controller: _pageController,
                      count: images.length,
                      effect: ScrollingDotsEffect(
                        activeDotColor: Colors.black,
                        dotColor: Colors.grey.shade300,
                        dotHeight: 8.h,
                        dotWidth: 8.w,
                      ),
                    ),
                  ),
                  Positioned(
                    top: 10,
                    right: 18,
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withOpacity(0.3),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(2.0),
                        child: Icon(
                          Icons.favorite_border,
                          size: 20,
                          color: AppColors.black,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            /// Content
            Expanded(
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 10,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      /// Title
                      Text(
                        widget.name.toString(),
                        style: GoogleFonts.inter(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w700,
                          color: AppColors.indicatorColor,
                        ),
                      ),
                      SizedBox(height: 2.h),

                      /// Location / Price / Mileage Row
                      Row(
                        children: [
                          Icon(
                            Icons.location_on_outlined,
                            color: AppColors.primaryColor,
                            size: 14.sp,
                          ),
                          SizedBox(
                            width: Get.width * 0.5,
                            child: Text(
                              " $address",
                              style: GoogleFonts.inter(
                                fontSize: 11.sp,
                                color: AppColors.black,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          SizedBox(width: 20.w),
                          Icon(
                            Icons.attach_money_outlined,
                            color: AppColors.primaryColor,
                            size: 14.sp,
                          ),
                          Text(
                            getField("Price"),
                            style: GoogleFonts.inter(
                              fontSize: 11.sp,
                              color: AppColors.black,
                            ),
                          ),
                          SizedBox(width: 20.w),
                          Image.asset(
                            "assets/icons/meter.png",
                            color: AppColors.primaryColor,
                            width: 14.w,
                          ),
                          Text(
                            " ${getField("Mileage")}",
                            style: GoogleFonts.inter(
                              fontSize: 11.sp,
                              color: AppColors.black,
                            ),
                          ),
                        ],
                      ),

                      Divider(color: AppColors.appBar, thickness: 0.4),

                      /// Description
                      Text(
                        "Description",
                        style: GoogleFonts.inter(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w700,
                          color: AppColors.indicatorColor,
                        ),
                      ),
                      SizedBox(height: 2.h),
                      Text(
                        getField("Description"),
                        style: GoogleFonts.inter(
                          fontSize: 11.sp,
                          color: AppColors.black,
                        ),
                      ),
                      SizedBox(height: 12.h),

                      /// Details
                      Text(
                        "Details",
                        style: GoogleFonts.inter(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w700,
                          color: AppColors.indicatorColor,
                        ),
                      ),

                      /// Animated Size Section
                      AnimatedSize(
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeInOut,
                        child: Column(
                          children: [
                            ...fields
                                .take(
                                  _showMore ? fields.length : _initialVisible,
                                )
                                .map(
                                  (field) => _buildRow(
                                    field.fieldName!,
                                    field.optionValue!,
                                  ),
                                )
                                .toList(),
                          ],
                        ),
                      ),

                      /// See More / Less
                      if (fields.length > _initialVisible) ...[
                        SizedBox(height: 8.h),
                        GestureDetector(
                          onTap: () {
                            setState(() => _showMore = !_showMore);
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                _showMore ? "See Less" : "See More",
                                style: GoogleFonts.inter(
                                  fontSize: 12.sp,
                                  color: AppColors.primaryColor,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              Icon(
                                _showMore
                                    ? Icons.keyboard_arrow_up
                                    : Icons.keyboard_arrow_down,
                                color: AppColors.primaryColor,
                              ),
                            ],
                          ),
                        ),
                      ],

                      SizedBox(height: 10.h),
                      InkWell(
                        onTap: () async {},
                        child: Container(
                          height: AppDimentions.pxh_45,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            color: AppColors.indicatorColor,
                          ),
                          child: Center(
                            child: Text(
                              "Get a Quote",
                              style: GoogleFonts.inter(
                                color: AppColors.white,
                                fontSize: AppDimentions.sp16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 20.h),
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      }),
    );
  }
}

Widget _buildRow(String label, String value) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(
        label,
        style: GoogleFonts.inter(
          fontSize: 12.sp,
          color: AppColors.dotColor1,
          fontWeight: FontWeight.w600,
        ),
      ),
      Text(
        value,
        style: GoogleFonts.inter(fontSize: 12.sp, color: AppColors.black),
      ),
    ],
  );
}
